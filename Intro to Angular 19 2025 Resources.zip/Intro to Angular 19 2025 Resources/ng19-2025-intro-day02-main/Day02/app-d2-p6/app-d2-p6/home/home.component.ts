import { Component, OnInit, computed, signal } from '@angular/core';
//
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styles: ``
})
//
export class HomeComponent implements OnInit {
  fName = signal('Axle');
  lName = signal('');
  constructor(){
    //this.fName.update( prevValue => "AxleB" );
  };
  //
  ngOnInit(): void {
    this.lName.set('Barr');
  };
  //
  getFullName(){
    return computed(()=>this.fName() + ' ' + this.lName())();
  };
};
