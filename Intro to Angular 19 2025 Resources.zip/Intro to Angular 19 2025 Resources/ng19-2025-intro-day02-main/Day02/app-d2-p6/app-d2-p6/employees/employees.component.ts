import { Component, OnInit } from '@angular/core';
import { CommonModule } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
//
interface Employee {
  id : string;
  username : string;
  password: string;
}
//
@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './employees.component.html',
  styles: ``
})
//
export class EmployeesComponent implements OnInit{
  employees$! : Observable<Employee[]>;
  constructor(private http:HttpClient){};
  ngOnInit(): void {
    this.employees$ = this.http.get<Employee[]>("http://localhost:3000/employees");
    this.employees$.subscribe(data => {
      console.log(data);
    });
    //console.log(this.employees$);

  }

}
