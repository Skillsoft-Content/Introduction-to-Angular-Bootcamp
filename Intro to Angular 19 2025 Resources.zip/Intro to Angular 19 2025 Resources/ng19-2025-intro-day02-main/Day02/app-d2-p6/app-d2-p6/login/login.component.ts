import { Component } from '@angular/core';
import { FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { Observable } from 'rxjs/internal/Observable';
//
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styles: ``
})
//
export class LoginComponent {
  user$!: Observable<any>;
  loginForm = new FormGroup({
    userName : new FormControl('', [Validators.required]),
    password : new FormControl('', [Validators.required])
  });
  //currentUser = this.loginForm.value.userName;
  //currentPassword = this.loginForm.value.password;
  constructor(private http:HttpClient, private router:Router) {};
  onSubmit() {
    let currentUser = this.loginForm.value.userName;
    let currentPassword = this.loginForm.value.password;
    this.user$ = this.http.get(
      'http://localhost:3000/employees',
      {
        params:{username:currentUser!}
      }
    );
    this.user$.subscribe(data => {
      //console.log(data);

      if(currentUser == data[0].username && data[0].password == currentPassword){
        console.log("User is valid");
        localStorage.setItem('validuser', currentUser!);
        this.router.navigateByUrl('/home');
      } else {
        console.log("User is not valid");
        this.router.navigateByUrl('/login');
      }
    });
  }
}
