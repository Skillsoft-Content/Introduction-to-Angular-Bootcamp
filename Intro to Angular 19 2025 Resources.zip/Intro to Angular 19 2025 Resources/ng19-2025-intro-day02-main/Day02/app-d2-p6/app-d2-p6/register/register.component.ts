import { Component } from '@angular/core';
import { FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from "@angular/common/http";
//
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styles: ``
})
//
export class RegisterComponent {
  registerForm = new FormGroup({
    username : new FormControl('', [Validators.required]),
    password : new FormControl('', [Validators.required])
  });
  constructor(private http:HttpClient) {};
  onSubmit() {
    this.http.post(
      'http://localhost:3000/employees',
      this.registerForm.value
    )
    .subscribe({
      next : data => console.log(data),
      error : err => console.log(err),
      complete : () => console.log("Post was successful!"),
    });
    console.log(
      //this.registerForm.value
      // `You entered : userName:
      // ${this.registerForm.controls['userName'].value},
      // And password:
      // ${this.registerForm.controls['password'].value}`,
    );
  }

}
