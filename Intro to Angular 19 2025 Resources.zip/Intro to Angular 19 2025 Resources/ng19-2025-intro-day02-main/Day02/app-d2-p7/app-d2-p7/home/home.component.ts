import { Component, OnInit, computed, signal } from '@angular/core';
import { FormArrayName } from '@angular/forms';
//
interface Employee {
  fName : string;
  lName: string;
}
//
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styles: ``
})
//
export class HomeComponent implements OnInit {
  //fName = signal('Axle');
  //lName = signal('');
  Axle = signal<Employee>({
    fName : 'Axle',
    lName : ''
  });
  constructor(){
    //this.fName.update( prevValue => "AxleB" );
  };
  //
  ngOnInit(): void {
    this.Axle.update( o => {
      o.lName='Barr';
      return o }
    );
  };
  //
  getFullName(){
    return this.Axle();
  };
};
