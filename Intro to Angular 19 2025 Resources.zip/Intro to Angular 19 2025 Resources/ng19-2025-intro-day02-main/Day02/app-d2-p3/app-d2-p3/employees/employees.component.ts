import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common'; // Add this line
//
interface Employee {
  id : string;
  username : string;
  password: string;
}
//
@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [CommonModule], // Add CommonModule to the imports array
  templateUrl: './employees.component.html',
  styles: ``
})
//
export class EmployeesComponent implements OnInit {
  employees$!: Observable<Employee[]>;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.employees$ = this.http.get<Employee[]>('http://localhost:3000/employees');
    //console.log(this.employees$);
  }
}
//


