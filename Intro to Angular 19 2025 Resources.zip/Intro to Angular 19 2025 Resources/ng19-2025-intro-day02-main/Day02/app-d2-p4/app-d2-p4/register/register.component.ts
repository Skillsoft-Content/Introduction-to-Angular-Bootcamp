import { Component } from '@angular/core';
import { FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from "@angular/common/http";
//
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
//
export class RegisterComponent {
//
  registerForm = new FormGroup({
    username: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });
//
  constructor(private http: HttpClient) { };
  onSubmit() {
    this.http.post(
      'http://localhost:3000/employees',
      this.registerForm.value
    ).subscribe(
      {
        next:data => console.log(data),
        complete:()=> console.log("Data returned"),
        error: err => console.log(err)
      }
    )
  }
}

